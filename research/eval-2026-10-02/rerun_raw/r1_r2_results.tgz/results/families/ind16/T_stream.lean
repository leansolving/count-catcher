import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream grid16_indepSets via (grid_card_of_check (n := 16)) "/scratch/szeider/121003/ind16/fwd.pog" "/scratch/szeider/121003/ind16/fwd.lrat" (keep := "/scratch/szeider/121003/ind16/fwd.keep") (count := 18396766424410124752958806046933947217821482942)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms grid16_indepSets
