import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream queens12 via (Queens.card_of_check (n := 12)) "/scratch/szeider/121007/q12/fwd.pog" "/scratch/szeider/121007/q12/fwd.lrat" (keep := "/scratch/szeider/121007/q12/fwd.keep") (count := 14200)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms queens12
