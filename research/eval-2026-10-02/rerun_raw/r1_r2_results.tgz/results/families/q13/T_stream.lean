import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream queens13 via (Queens.card_of_check (n := 13)) "/scratch/szeider/121004/q13/fwd.pog" "/scratch/szeider/121004/q13/fwd.lrat" (keep := "/scratch/szeider/121004/q13/fwd.keep") (count := 73712)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms queens13
