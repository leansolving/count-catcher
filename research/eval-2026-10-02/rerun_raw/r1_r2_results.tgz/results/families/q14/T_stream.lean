import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream queens14 via (Queens.card_of_check (n := 14)) "/scratch/szeider/121002/q14/fwd.pog" "/scratch/szeider/121002/q14/fwd.lrat" (keep := "/scratch/szeider/121002/q14/fwd.keep") (count := 365596)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms queens14
