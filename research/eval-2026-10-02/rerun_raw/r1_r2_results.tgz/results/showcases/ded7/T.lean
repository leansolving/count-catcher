import McCertTool

open McCert

set_option mccert.embedMaxBytes 67108864

/-- The Dedekind number M(7): monotone Boolean functions on 7 variables. -/
count_models dedekind7 via (McCert.Dedekind.card_of_check (n := 7)) "/scratch/szeider/121016/ded7/work/fwd.pog" "/scratch/szeider/121016/ded7/work/fwd.lrat" (keep := "/scratch/szeider/121016/ded7/work/fwd.keep") (count := 2414682040998)

example : Nat.card {f : (Fin 7 → Bool) → Bool // Monotone f} = 2414682040998 :=
  dedekind7

#print axioms dedekind7
