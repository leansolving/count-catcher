import McCertTool

open McCert

set_option mccert.embedMaxBytes 67108864

/-- A358391(6): antichains of the Kreweras lattice NC(6). -/
count_models kreweras6 via (McCert.Kreweras.card_of_check (n := 6)) "/scratch/szeider/121018/krew6/work/fwd.pog" "/scratch/szeider/121018/krew6/work/fwd.lrat" (keep := "/scratch/szeider/121018/krew6/work/fwd.keep") (count := 206103695057137712)

example : Nat.card {A : Set {P : Setoid (Fin 6) // P.IsNoncrossing} // IsAntichain (· ≤ ·) A} = 206103695057137712 :=
  kreweras6

#print axioms kreweras6
