import McCertTool
import McCertMath.Families.GraphIso

open SimpleGraph McCert McCert.GraphIso McCert.CycleType

set_option mccert.embedMaxBytes 67108864
set_option maxRecDepth 100000

count_models ramsey35_13_fix_13 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [13])) "/scratch/szeider/121015/r35_13/work/13/fwd.pog" "/scratch/szeider/121015/r35_13/work/13/fwd.lrat" (count := 3)
count_models ramsey35_13_fix_12 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [12])) "/scratch/szeider/121015/r35_13/work/12/unsat.lrat"
count_models ramsey35_13_fix_11_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [11, 2])) "/scratch/szeider/121015/r35_13/work/11_2/unsat.lrat"
count_models ramsey35_13_fix_11 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [11])) "/scratch/szeider/121015/r35_13/work/11/unsat.lrat"
count_models ramsey35_13_fix_10_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [10, 3])) "/scratch/szeider/121015/r35_13/work/10_3/unsat.lrat"
count_models ramsey35_13_fix_10_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [10, 2])) "/scratch/szeider/121015/r35_13/work/10_2/unsat.lrat"
count_models ramsey35_13_fix_10 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [10])) "/scratch/szeider/121015/r35_13/work/10/unsat.lrat"
count_models ramsey35_13_fix_9_4 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [9, 4])) "/scratch/szeider/121015/r35_13/work/9_4/unsat.lrat"
count_models ramsey35_13_fix_9_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [9, 3])) "/scratch/szeider/121015/r35_13/work/9_3/unsat.lrat"
count_models ramsey35_13_fix_9_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [9, 2, 2])) "/scratch/szeider/121015/r35_13/work/9_2_2/unsat.lrat"
count_models ramsey35_13_fix_9_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [9, 2])) "/scratch/szeider/121015/r35_13/work/9_2/unsat.lrat"
count_models ramsey35_13_fix_9 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [9])) "/scratch/szeider/121015/r35_13/work/9/unsat.lrat"
count_models ramsey35_13_fix_8_5 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [8, 5])) "/scratch/szeider/121015/r35_13/work/8_5/unsat.lrat"
count_models ramsey35_13_fix_8_4 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [8, 4])) "/scratch/szeider/121015/r35_13/work/8_4/unsat.lrat"
count_models ramsey35_13_fix_8_3_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [8, 3, 2])) "/scratch/szeider/121015/r35_13/work/8_3_2/unsat.lrat"
count_models ramsey35_13_fix_8_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [8, 3])) "/scratch/szeider/121015/r35_13/work/8_3/unsat.lrat"
count_models ramsey35_13_fix_8_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [8, 2, 2])) "/scratch/szeider/121015/r35_13/work/8_2_2/unsat.lrat"
count_models ramsey35_13_fix_8_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [8, 2])) "/scratch/szeider/121015/r35_13/work/8_2/unsat.lrat"
count_models ramsey35_13_fix_8 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [8])) "/scratch/szeider/121015/r35_13/work/8/unsat.lrat"
count_models ramsey35_13_fix_7_6 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [7, 6])) "/scratch/szeider/121015/r35_13/work/7_6/unsat.lrat"
count_models ramsey35_13_fix_7_5 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [7, 5])) "/scratch/szeider/121015/r35_13/work/7_5/unsat.lrat"
count_models ramsey35_13_fix_7_4_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [7, 4, 2])) "/scratch/szeider/121015/r35_13/work/7_4_2/unsat.lrat"
count_models ramsey35_13_fix_7_4 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [7, 4])) "/scratch/szeider/121015/r35_13/work/7_4/unsat.lrat"
count_models ramsey35_13_fix_7_3_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [7, 3, 3])) "/scratch/szeider/121015/r35_13/work/7_3_3/unsat.lrat"
count_models ramsey35_13_fix_7_3_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [7, 3, 2])) "/scratch/szeider/121015/r35_13/work/7_3_2/unsat.lrat"
count_models ramsey35_13_fix_7_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [7, 3])) "/scratch/szeider/121015/r35_13/work/7_3/unsat.lrat"
count_models ramsey35_13_fix_7_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [7, 2, 2, 2])) "/scratch/szeider/121015/r35_13/work/7_2_2_2/unsat.lrat"
count_models ramsey35_13_fix_7_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [7, 2, 2])) "/scratch/szeider/121015/r35_13/work/7_2_2/unsat.lrat"
count_models ramsey35_13_fix_7_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [7, 2])) "/scratch/szeider/121015/r35_13/work/7_2/unsat.lrat"
count_models ramsey35_13_fix_7 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [7])) "/scratch/szeider/121015/r35_13/work/7/unsat.lrat"
count_models ramsey35_13_fix_6_6 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [6, 6])) "/scratch/szeider/121015/r35_13/work/6_6/unsat.lrat"
count_models ramsey35_13_fix_6_5_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [6, 5, 2])) "/scratch/szeider/121015/r35_13/work/6_5_2/unsat.lrat"
count_models ramsey35_13_fix_6_5 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [6, 5])) "/scratch/szeider/121015/r35_13/work/6_5/unsat.lrat"
count_models ramsey35_13_fix_6_4_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [6, 4, 3])) "/scratch/szeider/121015/r35_13/work/6_4_3/unsat.lrat"
count_models ramsey35_13_fix_6_4_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [6, 4, 2])) "/scratch/szeider/121015/r35_13/work/6_4_2/unsat.lrat"
count_models ramsey35_13_fix_6_4 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [6, 4])) "/scratch/szeider/121015/r35_13/work/6_4/unsat.lrat"
count_models ramsey35_13_fix_6_3_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [6, 3, 3])) "/scratch/szeider/121015/r35_13/work/6_3_3/unsat.lrat"
count_models ramsey35_13_fix_6_3_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [6, 3, 2, 2])) "/scratch/szeider/121015/r35_13/work/6_3_2_2/unsat.lrat"
count_models ramsey35_13_fix_6_3_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [6, 3, 2])) "/scratch/szeider/121015/r35_13/work/6_3_2/unsat.lrat"
count_models ramsey35_13_fix_6_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [6, 3])) "/scratch/szeider/121015/r35_13/work/6_3/unsat.lrat"
count_models ramsey35_13_fix_6_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [6, 2, 2, 2])) "/scratch/szeider/121015/r35_13/work/6_2_2_2/unsat.lrat"
count_models ramsey35_13_fix_6_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [6, 2, 2])) "/scratch/szeider/121015/r35_13/work/6_2_2/unsat.lrat"
count_models ramsey35_13_fix_6_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [6, 2])) "/scratch/szeider/121015/r35_13/work/6_2/unsat.lrat"
count_models ramsey35_13_fix_6 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [6])) "/scratch/szeider/121015/r35_13/work/6/unsat.lrat"
count_models ramsey35_13_fix_5_5_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 5, 3])) "/scratch/szeider/121015/r35_13/work/5_5_3/unsat.lrat"
count_models ramsey35_13_fix_5_5_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 5, 2])) "/scratch/szeider/121015/r35_13/work/5_5_2/unsat.lrat"
count_models ramsey35_13_fix_5_5 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 5])) "/scratch/szeider/121015/r35_13/work/5_5/unsat.lrat"
count_models ramsey35_13_fix_5_4_4 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 4, 4])) "/scratch/szeider/121015/r35_13/work/5_4_4/unsat.lrat"
count_models ramsey35_13_fix_5_4_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 4, 3])) "/scratch/szeider/121015/r35_13/work/5_4_3/unsat.lrat"
count_models ramsey35_13_fix_5_4_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 4, 2, 2])) "/scratch/szeider/121015/r35_13/work/5_4_2_2/unsat.lrat"
count_models ramsey35_13_fix_5_4_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 4, 2])) "/scratch/szeider/121015/r35_13/work/5_4_2/unsat.lrat"
count_models ramsey35_13_fix_5_4 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 4])) "/scratch/szeider/121015/r35_13/work/5_4/unsat.lrat"
count_models ramsey35_13_fix_5_3_3_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 3, 3, 2])) "/scratch/szeider/121015/r35_13/work/5_3_3_2/unsat.lrat"
count_models ramsey35_13_fix_5_3_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 3, 3])) "/scratch/szeider/121015/r35_13/work/5_3_3/unsat.lrat"
count_models ramsey35_13_fix_5_3_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 3, 2, 2])) "/scratch/szeider/121015/r35_13/work/5_3_2_2/unsat.lrat"
count_models ramsey35_13_fix_5_3_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 3, 2])) "/scratch/szeider/121015/r35_13/work/5_3_2/unsat.lrat"
count_models ramsey35_13_fix_5_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 3])) "/scratch/szeider/121015/r35_13/work/5_3/unsat.lrat"
count_models ramsey35_13_fix_5_2_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 2, 2, 2, 2])) "/scratch/szeider/121015/r35_13/work/5_2_2_2_2/unsat.lrat"
count_models ramsey35_13_fix_5_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 2, 2, 2])) "/scratch/szeider/121015/r35_13/work/5_2_2_2/unsat.lrat"
count_models ramsey35_13_fix_5_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 2, 2])) "/scratch/szeider/121015/r35_13/work/5_2_2/unsat.lrat"
count_models ramsey35_13_fix_5_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5, 2])) "/scratch/szeider/121015/r35_13/work/5_2/unsat.lrat"
count_models ramsey35_13_fix_5 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [5])) "/scratch/szeider/121015/r35_13/work/5/unsat.lrat"
count_models ramsey35_13_fix_4_4_4 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 4, 4])) "/scratch/szeider/121015/r35_13/work/4_4_4/fwd.pog" "/scratch/szeider/121015/r35_13/work/4_4_4/fwd.lrat" (count := 192)
count_models ramsey35_13_fix_4_4_3_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 4, 3, 2])) "/scratch/szeider/121015/r35_13/work/4_4_3_2/unsat.lrat"
count_models ramsey35_13_fix_4_4_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 4, 3])) "/scratch/szeider/121015/r35_13/work/4_4_3/unsat.lrat"
count_models ramsey35_13_fix_4_4_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 4, 2, 2])) "/scratch/szeider/121015/r35_13/work/4_4_2_2/unsat.lrat"
count_models ramsey35_13_fix_4_4_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 4, 2])) "/scratch/szeider/121015/r35_13/work/4_4_2/unsat.lrat"
count_models ramsey35_13_fix_4_4 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 4])) "/scratch/szeider/121015/r35_13/work/4_4/unsat.lrat"
count_models ramsey35_13_fix_4_3_3_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 3, 3, 3])) "/scratch/szeider/121015/r35_13/work/4_3_3_3/unsat.lrat"
count_models ramsey35_13_fix_4_3_3_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 3, 3, 2])) "/scratch/szeider/121015/r35_13/work/4_3_3_2/unsat.lrat"
count_models ramsey35_13_fix_4_3_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 3, 3])) "/scratch/szeider/121015/r35_13/work/4_3_3/unsat.lrat"
count_models ramsey35_13_fix_4_3_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 3, 2, 2, 2])) "/scratch/szeider/121015/r35_13/work/4_3_2_2_2/unsat.lrat"
count_models ramsey35_13_fix_4_3_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 3, 2, 2])) "/scratch/szeider/121015/r35_13/work/4_3_2_2/unsat.lrat"
count_models ramsey35_13_fix_4_3_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 3, 2])) "/scratch/szeider/121015/r35_13/work/4_3_2/unsat.lrat"
count_models ramsey35_13_fix_4_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 3])) "/scratch/szeider/121015/r35_13/work/4_3/unsat.lrat"
count_models ramsey35_13_fix_4_2_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 2, 2, 2, 2])) "/scratch/szeider/121015/r35_13/work/4_2_2_2_2/unsat.lrat"
count_models ramsey35_13_fix_4_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 2, 2, 2])) "/scratch/szeider/121015/r35_13/work/4_2_2_2/unsat.lrat"
count_models ramsey35_13_fix_4_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 2, 2])) "/scratch/szeider/121015/r35_13/work/4_2_2/unsat.lrat"
count_models ramsey35_13_fix_4_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4, 2])) "/scratch/szeider/121015/r35_13/work/4_2/unsat.lrat"
count_models ramsey35_13_fix_4 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [4])) "/scratch/szeider/121015/r35_13/work/4/unsat.lrat"
count_models ramsey35_13_fix_3_3_3_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [3, 3, 3, 3])) "/scratch/szeider/121015/r35_13/work/3_3_3_3/unsat.lrat"
count_models ramsey35_13_fix_3_3_3_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [3, 3, 3, 2, 2])) "/scratch/szeider/121015/r35_13/work/3_3_3_2_2/unsat.lrat"
count_models ramsey35_13_fix_3_3_3_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [3, 3, 3, 2])) "/scratch/szeider/121015/r35_13/work/3_3_3_2/unsat.lrat"
count_models ramsey35_13_fix_3_3_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [3, 3, 3])) "/scratch/szeider/121015/r35_13/work/3_3_3/unsat.lrat"
count_models ramsey35_13_fix_3_3_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [3, 3, 2, 2, 2])) "/scratch/szeider/121015/r35_13/work/3_3_2_2_2/unsat.lrat"
count_models ramsey35_13_fix_3_3_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [3, 3, 2, 2])) "/scratch/szeider/121015/r35_13/work/3_3_2_2/unsat.lrat"
count_models ramsey35_13_fix_3_3_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [3, 3, 2])) "/scratch/szeider/121015/r35_13/work/3_3_2/unsat.lrat"
count_models ramsey35_13_fix_3_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [3, 3])) "/scratch/szeider/121015/r35_13/work/3_3/unsat.lrat"
count_models ramsey35_13_fix_3_2_2_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [3, 2, 2, 2, 2, 2])) "/scratch/szeider/121015/r35_13/work/3_2_2_2_2_2/unsat.lrat"
count_models ramsey35_13_fix_3_2_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [3, 2, 2, 2, 2])) "/scratch/szeider/121015/r35_13/work/3_2_2_2_2/unsat.lrat"
count_models ramsey35_13_fix_3_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [3, 2, 2, 2])) "/scratch/szeider/121015/r35_13/work/3_2_2_2/unsat.lrat"
count_models ramsey35_13_fix_3_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [3, 2, 2])) "/scratch/szeider/121015/r35_13/work/3_2_2/unsat.lrat"
count_models ramsey35_13_fix_3_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [3, 2])) "/scratch/szeider/121015/r35_13/work/3_2/unsat.lrat"
count_models ramsey35_13_fix_3 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [3])) "/scratch/szeider/121015/r35_13/work/3/unsat.lrat"
count_models ramsey35_13_fix_2_2_2_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [2, 2, 2, 2, 2, 2])) "/scratch/szeider/121015/r35_13/work/2_2_2_2_2_2/fwd.pog" "/scratch/szeider/121015/r35_13/work/2_2_2_2_2_2/fwd.lrat" (keep := "/scratch/szeider/121015/r35_13/work/2_2_2_2_2_2/fwd.keep") (count := 11520)
count_models ramsey35_13_fix_2_2_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [2, 2, 2, 2, 2])) "/scratch/szeider/121015/r35_13/work/2_2_2_2_2/unsat.lrat"
count_models ramsey35_13_fix_2_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [2, 2, 2, 2])) "/scratch/szeider/121015/r35_13/work/2_2_2_2/unsat.lrat"
count_models ramsey35_13_fix_2_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [2, 2, 2])) "/scratch/szeider/121015/r35_13/work/2_2_2/unsat.lrat"
count_models ramsey35_13_fix_2_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [2, 2])) "/scratch/szeider/121015/r35_13/work/2_2/unsat.lrat"
count_models ramsey35_13_fix_2 via (RamseyFam.fix_card_of_check (n := 13) (s := 3) (t := 5) (l := [2])) "/scratch/szeider/121015/r35_13/work/2/unsat.lrat"
count_models ramsey35_13_nbr_0 via (RamseyFam.nbr_card_of_check (n := 13) (s := 3) (t := 5) (k := 0)) "/scratch/szeider/121015/r35_13/work/nbr_0/unsat.lrat"
count_models ramsey35_13_nbr_1 via (RamseyFam.nbr_card_of_check (n := 13) (s := 3) (t := 5) (k := 1)) "/scratch/szeider/121015/r35_13/work/nbr_1/unsat.lrat"
count_models ramsey35_13_nbr_2 via (RamseyFam.nbr_card_of_check (n := 13) (s := 3) (t := 5) (k := 2)) "/scratch/szeider/121015/r35_13/work/nbr_2/unsat.lrat"
count_models ramsey35_13_nbr_3 via (RamseyFam.nbr_card_of_check (n := 13) (s := 3) (t := 5) (k := 3)) "/scratch/szeider/121015/r35_13/work/nbr_3/unsat.lrat"
count_models ramsey35_13_nbr_4 via (RamseyFam.nbr_card_of_check (n := 13) (s := 3) (t := 5) (k := 4)) "/scratch/szeider/121015/r35_13/work/nbr_4/fwd.pog" "/scratch/szeider/121015/r35_13/work/nbr_4/fwd.lrat" (keep := "/scratch/szeider/121015/r35_13/work/nbr_4/fwd.keep") (count := 241920)
count_models ramsey35_13_nbr_5 via (RamseyFam.nbr_card_of_check (n := 13) (s := 3) (t := 5) (k := 5)) "/scratch/szeider/121015/r35_13/work/nbr_5/unsat.lrat"
count_models ramsey35_13_nbr_6 via (RamseyFam.nbr_card_of_check (n := 13) (s := 3) (t := 5) (k := 6)) "/scratch/szeider/121015/r35_13/work/nbr_6/unsat.lrat"
count_models ramsey35_13_nbr_7 via (RamseyFam.nbr_card_of_check (n := 13) (s := 3) (t := 5) (k := 7)) "/scratch/szeider/121015/r35_13/work/nbr_7/unsat.lrat"
count_models ramsey35_13_nbr_8 via (RamseyFam.nbr_card_of_check (n := 13) (s := 3) (t := 5) (k := 8)) "/scratch/szeider/121015/r35_13/work/nbr_8/unsat.lrat"
count_models ramsey35_13_nbr_9 via (RamseyFam.nbr_card_of_check (n := 13) (s := 3) (t := 5) (k := 9)) "/scratch/szeider/121015/r35_13/work/nbr_9/unsat.lrat"
count_models ramsey35_13_nbr_10 via (RamseyFam.nbr_card_of_check (n := 13) (s := 3) (t := 5) (k := 10)) "/scratch/szeider/121015/r35_13/work/nbr_10/unsat.lrat"
count_models ramsey35_13_nbr_11 via (RamseyFam.nbr_card_of_check (n := 13) (s := 3) (t := 5) (k := 11)) "/scratch/szeider/121015/r35_13/work/nbr_11/unsat.lrat"
count_models ramsey35_13_nbr_12 via (RamseyFam.nbr_card_of_check (n := 13) (s := 3) (t := 5) (k := 12)) "/scratch/szeider/121015/r35_13/work/nbr_12/unsat.lrat"

/-- The labelled count, from the counts per neighbourhood of vertex `0`. -/
theorem ramsey35_13 : Nat.card {G : SimpleGraph (Fin 13) // G.CliqueFree 3 ∧ Gᶜ.CliqueFree 5} = 119750400 :=
  RamseyFam.card_eq_of_split 119750400
    [(0, 0),
     (1, 0),
     (2, 0),
     (3, 0),
     (4, 241920),
     (5, 0),
     (6, 0),
     (7, 0),
     (8, 0),
     (9, 0),
     (10, 0),
     (11, 0),
     (12, 0)]
    (List.forall_mem_cons.2 ⟨ramsey35_13_nbr_0,
      List.forall_mem_cons.2 ⟨ramsey35_13_nbr_1,
      List.forall_mem_cons.2 ⟨ramsey35_13_nbr_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_nbr_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_nbr_4,
      List.forall_mem_cons.2 ⟨ramsey35_13_nbr_5,
      List.forall_mem_cons.2 ⟨ramsey35_13_nbr_6,
      List.forall_mem_cons.2 ⟨ramsey35_13_nbr_7,
      List.forall_mem_cons.2 ⟨ramsey35_13_nbr_8,
      List.forall_mem_cons.2 ⟨ramsey35_13_nbr_9,
      List.forall_mem_cons.2 ⟨ramsey35_13_nbr_10,
      List.forall_mem_cons.2 ⟨ramsey35_13_nbr_11,
      List.forall_mem_cons.2 ⟨ramsey35_13_nbr_12,
      List.forall_mem_nil _⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩)
    (by decide)

/-- The number of graphs on 13 vertices without a 3-clique and without an independent 5-set, up to relabelling (orbits of `Perm (Fin 13)`), by
    Burnside's lemma over the cycle types from the certified counts above. -/
theorem ramsey35_13_orbits :
    Nat.card (MulAction.orbitRel.Quotient (Equiv.Perm (Fin 13))
      {G : SimpleGraph (Fin 13) // G.CliqueFree 3 ∧ Gᶜ.CliqueFree 5}) = 1 :=
  RamseyFam.card_orbits_eq 1
    [([13], 3),
     ([12], 0),
     ([11, 2], 0),
     ([11], 0),
     ([10, 3], 0),
     ([10, 2], 0),
     ([10], 0),
     ([9, 4], 0),
     ([9, 3], 0),
     ([9, 2, 2], 0),
     ([9, 2], 0),
     ([9], 0),
     ([8, 5], 0),
     ([8, 4], 0),
     ([8, 3, 2], 0),
     ([8, 3], 0),
     ([8, 2, 2], 0),
     ([8, 2], 0),
     ([8], 0),
     ([7, 6], 0),
     ([7, 5], 0),
     ([7, 4, 2], 0),
     ([7, 4], 0),
     ([7, 3, 3], 0),
     ([7, 3, 2], 0),
     ([7, 3], 0),
     ([7, 2, 2, 2], 0),
     ([7, 2, 2], 0),
     ([7, 2], 0),
     ([7], 0),
     ([6, 6], 0),
     ([6, 5, 2], 0),
     ([6, 5], 0),
     ([6, 4, 3], 0),
     ([6, 4, 2], 0),
     ([6, 4], 0),
     ([6, 3, 3], 0),
     ([6, 3, 2, 2], 0),
     ([6, 3, 2], 0),
     ([6, 3], 0),
     ([6, 2, 2, 2], 0),
     ([6, 2, 2], 0),
     ([6, 2], 0),
     ([6], 0),
     ([5, 5, 3], 0),
     ([5, 5, 2], 0),
     ([5, 5], 0),
     ([5, 4, 4], 0),
     ([5, 4, 3], 0),
     ([5, 4, 2, 2], 0),
     ([5, 4, 2], 0),
     ([5, 4], 0),
     ([5, 3, 3, 2], 0),
     ([5, 3, 3], 0),
     ([5, 3, 2, 2], 0),
     ([5, 3, 2], 0),
     ([5, 3], 0),
     ([5, 2, 2, 2, 2], 0),
     ([5, 2, 2, 2], 0),
     ([5, 2, 2], 0),
     ([5, 2], 0),
     ([5], 0),
     ([4, 4, 4], 192),
     ([4, 4, 3, 2], 0),
     ([4, 4, 3], 0),
     ([4, 4, 2, 2], 0),
     ([4, 4, 2], 0),
     ([4, 4], 0),
     ([4, 3, 3, 3], 0),
     ([4, 3, 3, 2], 0),
     ([4, 3, 3], 0),
     ([4, 3, 2, 2, 2], 0),
     ([4, 3, 2, 2], 0),
     ([4, 3, 2], 0),
     ([4, 3], 0),
     ([4, 2, 2, 2, 2], 0),
     ([4, 2, 2, 2], 0),
     ([4, 2, 2], 0),
     ([4, 2], 0),
     ([4], 0),
     ([3, 3, 3, 3], 0),
     ([3, 3, 3, 2, 2], 0),
     ([3, 3, 3, 2], 0),
     ([3, 3, 3], 0),
     ([3, 3, 2, 2, 2], 0),
     ([3, 3, 2, 2], 0),
     ([3, 3, 2], 0),
     ([3, 3], 0),
     ([3, 2, 2, 2, 2, 2], 0),
     ([3, 2, 2, 2, 2], 0),
     ([3, 2, 2, 2], 0),
     ([3, 2, 2], 0),
     ([3, 2], 0),
     ([3], 0),
     ([2, 2, 2, 2, 2, 2], 11520),
     ([2, 2, 2, 2, 2], 0),
     ([2, 2, 2, 2], 0),
     ([2, 2, 2], 0),
     ([2, 2], 0),
     ([2], 0),
     ([], 119750400)]
    (List.forall_mem_cons.2 ⟨ramsey35_13_fix_13,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_12,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_11_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_11,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_10_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_10_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_10,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_9_4,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_9_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_9_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_9_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_9,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_8_5,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_8_4,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_8_3_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_8_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_8_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_8_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_8,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_7_6,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_7_5,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_7_4_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_7_4,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_7_3_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_7_3_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_7_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_7_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_7_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_7_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_7,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_6_6,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_6_5_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_6_5,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_6_4_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_6_4_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_6_4,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_6_3_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_6_3_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_6_3_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_6_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_6_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_6_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_6_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_6,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_5_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_5_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_5,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_4_4,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_4_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_4_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_4_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_4,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_3_3_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_3_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_3_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_3_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_2_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_5,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_4_4,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_4_3_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_4_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_4_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_4_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_4,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_3_3_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_3_3_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_3_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_3_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_3_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_3_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_2_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_4,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_3_3_3_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_3_3_3_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_3_3_3_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_3_3_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_3_3_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_3_3_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_3_3_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_3_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_3_2_2_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_3_2_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_3_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_3_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_3_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_3,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_2_2_2_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_2_2_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_2_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_2_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_2_2,
      List.forall_mem_cons.2 ⟨ramsey35_13_fix_2,
      List.forall_mem_cons.2 ⟨RamseyFam.fix_nil ramsey35_13,
      List.forall_mem_nil _⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩)
    (by decide)

/-- The number of isomorphism classes of graphs on 13 vertices without a 3-clique and without an independent 5-set. -/
theorem ramsey35_13_isoClasses :
    Nat.card (Quot fun G H : {G : SimpleGraph (Fin 13) // G.CliqueFree 3 ∧ Gᶜ.CliqueFree 5} => Nonempty (G.1 ≃g H.1)) = 1 :=
  RamseyFam.card_isoClasses_eq ramsey35_13_orbits

/-- Every graph in the family is isomorphic to `(circulantGraph ({1, 5} : Set (Fin 13)))`. -/
theorem ramsey35_13_unique (G : SimpleGraph (Fin 13)) (h : G.CliqueFree 3 ∧ Gᶜ.CliqueFree 5) :
    Nonempty (G ≃g (circulantGraph ({1, 5} : Set (Fin 13)))) :=
  iso_of_card_isoClasses_eq_one ramsey35_13_isoClasses ⟨G, h⟩
    ⟨(circulantGraph ({1, 5} : Set (Fin 13))), ⟨cliqueFree_of_check _ 3 (by decide +kernel), compl_cliqueFree_of_check _ 5 (by decide +kernel)⟩⟩

#print axioms ramsey35_13_unique

#print axioms ramsey35_13_orbits
#print axioms ramsey35_13_isoClasses
#print axioms ramsey35_13
