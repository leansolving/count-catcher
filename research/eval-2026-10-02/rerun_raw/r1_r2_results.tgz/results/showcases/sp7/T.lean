import McCertTool

open McCert

set_option mccert.embedMaxBytes 67108864

/-- A396728(7): uncomplemented Sperner families on a 7-set. -/
count_models sperner7 via (McCert.Sperner.card_of_check (n := 7)) "/scratch/szeider/121019/sp7/work/fwd.pog" "/scratch/szeider/121019/sp7/work/fwd.lrat" (keep := "/scratch/szeider/121019/sp7/work/fwd.keep") (count := 696132184469)

example : Nat.card {F : Finset (Finset (Fin 7)) //
    IsAntichain (· ⊆ ·) (F : Set (Finset (Fin 7))) ∧ ∀ A ∈ F, Aᶜ ∉ F} = 696132184469 :=
  sperner7

#print axioms sperner7
