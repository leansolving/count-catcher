import McCertTool

open McCert

set_option mccert.embedMaxBytes 67108864

/-- OEIS A303210(10): total dominating sets of the 10 x 10 torus grid graph. -/
count_models A303210_10 via (McCert.TotalDom.torus_card_of_check (m := 8)) "/scratch/szeider/121021/td10/work/fwd.pog" "/scratch/szeider/121021/td10/work/fwd.lrat" (keep := "/scratch/szeider/121021/td10/work/fwd.keep") (count := 16751614615998096965673730489)

example : Nat.card {S : Finset (Fin 10 × Fin 10) //
    ∀ v, ∃ u ∈ S, (SimpleGraph.cycleGraph 10 □ SimpleGraph.cycleGraph 10).Adj v u} =
    16751614615998096965673730489 :=
  A303210_10

#print axioms A303210_10
