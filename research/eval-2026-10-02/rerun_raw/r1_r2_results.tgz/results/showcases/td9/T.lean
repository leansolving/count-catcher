import McCertTool

open McCert

set_option mccert.embedMaxBytes 67108864

/-- OEIS A303210(9): total dominating sets of the 9 x 9 torus grid graph. -/
count_models A303210_9 via (McCert.TotalDom.torus_card_of_check (m := 7)) "/scratch/szeider/121020/td9/work/fwd.pog" "/scratch/szeider/121020/td9/work/fwd.lrat" (keep := "/scratch/szeider/121020/td9/work/fwd.keep") (count := 72691237364024529045028)

example : Nat.card {S : Finset (Fin 9 × Fin 9) //
    ∀ v, ∃ u ∈ S, (SimpleGraph.cycleGraph 9 □ SimpleGraph.cycleGraph 9).Adj v u} =
    72691237364024529045028 :=
  A303210_9

#print axioms A303210_9
