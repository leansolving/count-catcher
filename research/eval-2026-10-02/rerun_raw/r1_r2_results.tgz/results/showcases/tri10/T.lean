import McCertTool
import McCertMath.Families.GraphIso

open SimpleGraph McCert McCert.GraphIso McCert.CycleType

set_option mccert.embedMaxBytes 67108864
set_option maxRecDepth 100000

count_models tri10_fix_10 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [10])) "/scratch/szeider/121014/tri10/work/10/fwd.pog" "/scratch/szeider/121014/tri10/work/10/fwd.lrat" (count := 14)
count_models tri10_fix_9 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [9])) "/scratch/szeider/121014/tri10/work/9/fwd.pog" "/scratch/szeider/121014/tri10/work/9/fwd.lrat" (count := 5)
count_models tri10_fix_8_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [8, 2])) "/scratch/szeider/121014/tri10/work/8_2/fwd.pog" "/scratch/szeider/121014/tri10/work/8_2/fwd.lrat" (count := 33)
count_models tri10_fix_8 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [8])) "/scratch/szeider/121014/tri10/work/8/fwd.pog" "/scratch/szeider/121014/tri10/work/8/fwd.lrat" (count := 21)
count_models tri10_fix_7_3 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [7, 3])) "/scratch/szeider/121014/tri10/work/7_3/fwd.pog" "/scratch/szeider/121014/tri10/work/7_3/fwd.lrat" (count := 5)
count_models tri10_fix_7_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [7, 2])) "/scratch/szeider/121014/tri10/work/7_2/fwd.pog" "/scratch/szeider/121014/tri10/work/7_2/fwd.lrat" (count := 18)
count_models tri10_fix_7 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [7])) "/scratch/szeider/121014/tri10/work/7/fwd.pog" "/scratch/szeider/121014/tri10/work/7/fwd.lrat" (count := 62)
count_models tri10_fix_6_4 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [6, 4])) "/scratch/szeider/121014/tri10/work/6_4/fwd.pog" "/scratch/szeider/121014/tri10/work/6_4/fwd.lrat" (count := 29)
count_models tri10_fix_6_3 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [6, 3])) "/scratch/szeider/121014/tri10/work/6_3/fwd.pog" "/scratch/szeider/121014/tri10/work/6_3/fwd.lrat" (count := 37)
count_models tri10_fix_6_2_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [6, 2, 2])) "/scratch/szeider/121014/tri10/work/6_2_2/fwd.pog" "/scratch/szeider/121014/tri10/work/6_2_2/fwd.lrat" (count := 411)
count_models tri10_fix_6_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [6, 2])) "/scratch/szeider/121014/tri10/work/6_2/fwd.pog" "/scratch/szeider/121014/tri10/work/6_2/fwd.lrat" (count := 175)
count_models tri10_fix_6 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [6])) "/scratch/szeider/121014/tri10/work/6/fwd.pog" "/scratch/szeider/121014/tri10/work/6/fwd.lrat" (count := 511)
count_models tri10_fix_5_5 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [5, 5])) "/scratch/szeider/121014/tri10/work/5_5/fwd.pog" "/scratch/szeider/121014/tri10/work/5_5/fwd.lrat" (count := 110)
count_models tri10_fix_5_4 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [5, 4])) "/scratch/szeider/121014/tri10/work/5_4/fwd.pog" "/scratch/szeider/121014/tri10/work/5_4/fwd.lrat" (count := 19)
count_models tri10_fix_5_3_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [5, 3, 2])) "/scratch/szeider/121014/tri10/work/5_3_2/fwd.pog" "/scratch/szeider/121014/tri10/work/5_3_2/fwd.lrat" (count := 15)
count_models tri10_fix_5_3 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [5, 3])) "/scratch/szeider/121014/tri10/work/5_3/fwd.pog" "/scratch/szeider/121014/tri10/work/5_3/fwd.lrat" (count := 55)
count_models tri10_fix_5_2_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [5, 2, 2])) "/scratch/szeider/121014/tri10/work/5_2_2/fwd.pog" "/scratch/szeider/121014/tri10/work/5_2_2/fwd.lrat" (count := 177)
count_models tri10_fix_5_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [5, 2])) "/scratch/szeider/121014/tri10/work/5_2/fwd.pog" "/scratch/szeider/121014/tri10/work/5_2/fwd.lrat" (count := 525)
count_models tri10_fix_5 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [5])) "/scratch/szeider/121014/tri10/work/5/fwd.pog" "/scratch/szeider/121014/tri10/work/5/fwd.lrat" (count := 6565)
count_models tri10_fix_4_4_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [4, 4, 2])) "/scratch/szeider/121014/tri10/work/4_4_2/fwd.pog" "/scratch/szeider/121014/tri10/work/4_4_2/fwd.lrat" (count := 757)
count_models tri10_fix_4_4 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [4, 4])) "/scratch/szeider/121014/tri10/work/4_4/fwd.pog" "/scratch/szeider/121014/tri10/work/4_4/fwd.lrat" (count := 541)
count_models tri10_fix_4_3_3 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [4, 3, 3])) "/scratch/szeider/121014/tri10/work/4_3_3/fwd.pog" "/scratch/szeider/121014/tri10/work/4_3_3/fwd.lrat" (count := 41)
count_models tri10_fix_4_3_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [4, 3, 2])) "/scratch/szeider/121014/tri10/work/4_3_2/fwd.pog" "/scratch/szeider/121014/tri10/work/4_3_2/fwd.lrat" (count := 130)
count_models tri10_fix_4_3 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [4, 3])) "/scratch/szeider/121014/tri10/work/4_3/fwd.pog" "/scratch/szeider/121014/tri10/work/4_3/fwd.lrat" (count := 470)
count_models tri10_fix_4_2_2_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [4, 2, 2, 2])) "/scratch/szeider/121014/tri10/work/4_2_2_2/fwd.pog" "/scratch/szeider/121014/tri10/work/4_2_2_2/fwd.lrat" (count := 8855)
count_models tri10_fix_4_2_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [4, 2, 2])) "/scratch/szeider/121014/tri10/work/4_2_2/fwd.pog" "/scratch/szeider/121014/tri10/work/4_2_2/fwd.lrat" (count := 4091)
count_models tri10_fix_4_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [4, 2])) "/scratch/szeider/121014/tri10/work/4_2/fwd.pog" "/scratch/szeider/121014/tri10/work/4_2/fwd.lrat" (count := 12643)
count_models tri10_fix_4 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [4])) "/scratch/szeider/121014/tri10/work/4/fwd.pog" "/scratch/szeider/121014/tri10/work/4/fwd.lrat" (count := 145079)
count_models tri10_fix_3_3_3 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [3, 3, 3])) "/scratch/szeider/121014/tri10/work/3_3_3/fwd.pog" "/scratch/szeider/121014/tri10/work/3_3_3/fwd.lrat" (count := 1049)
count_models tri10_fix_3_3_2_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [3, 3, 2, 2])) "/scratch/szeider/121014/tri10/work/3_3_2_2/fwd.pog" "/scratch/szeider/121014/tri10/work/3_3_2_2/fwd.lrat" (count := 427)
count_models tri10_fix_3_3_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [3, 3, 2])) "/scratch/szeider/121014/tri10/work/3_3_2/fwd.pog" "/scratch/szeider/121014/tri10/work/3_3_2/fwd.lrat" (count := 1371)
count_models tri10_fix_3_3 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [3, 3])) "/scratch/szeider/121014/tri10/work/3_3/fwd.pog" "/scratch/szeider/121014/tri10/work/3_3/fwd.lrat" (count := 17711)
count_models tri10_fix_3_2_2_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [3, 2, 2, 2])) "/scratch/szeider/121014/tri10/work/3_2_2_2/fwd.pog" "/scratch/szeider/121014/tri10/work/3_2_2_2/fwd.lrat" (count := 3970)
count_models tri10_fix_3_2_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [3, 2, 2])) "/scratch/szeider/121014/tri10/work/3_2_2/fwd.pog" "/scratch/szeider/121014/tri10/work/3_2_2/fwd.lrat" (count := 12214)
count_models tri10_fix_3_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [3, 2])) "/scratch/szeider/121014/tri10/work/3_2/fwd.pog" "/scratch/szeider/121014/tri10/work/3_2/fwd.lrat" (count := 139290)
count_models tri10_fix_3 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [3])) "/scratch/szeider/121014/tri10/work/3/fwd.pog" "/scratch/szeider/121014/tri10/work/3/fwd.lrat" (count := 4682270)
count_models tri10_fix_2_2_2_2_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [2, 2, 2, 2, 2])) "/scratch/szeider/121014/tri10/work/2_2_2_2_2/fwd.pog" "/scratch/szeider/121014/tri10/work/2_2_2_2_2/fwd.lrat" (count := 770649)
count_models tri10_fix_2_2_2_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [2, 2, 2, 2])) "/scratch/szeider/121014/tri10/work/2_2_2_2/fwd.pog" "/scratch/szeider/121014/tri10/work/2_2_2_2/fwd.lrat" (count := 298993)
count_models tri10_fix_2_2_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [2, 2, 2])) "/scratch/szeider/121014/tri10/work/2_2_2/fwd.pog" "/scratch/szeider/121014/tri10/work/2_2_2/fwd.lrat" (count := 811213)
count_models tri10_fix_2_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [2, 2])) "/scratch/szeider/121014/tri10/work/2_2/fwd.pog" "/scratch/szeider/121014/tri10/work/2_2/fwd.lrat" (count := 8440837)
count_models tri10_fix_2 via (CliqueFreeFam.fix_card_of_check (n := 10) (s := 3) (l := [2])) "/scratch/szeider/121014/tri10/work/2/fwd.pog" "/scratch/szeider/121014/tri10/work/2/fwd.lrat" (keep := "/scratch/szeider/121014/tri10/work/2/fwd.keep") (count := 251030385)
count_models tri10 via (CliqueFreeFam.card_of_check (n := 10) (s := 3)) "/scratch/szeider/121014/tri10/work/id/fwd.pog" "/scratch/szeider/121014/tri10/work/id/fwd.lrat" (keep := "/scratch/szeider/121014/tri10/work/id/fwd.keep") (count := 19213627145)

/-- The number of graphs on 10 vertices without a 3-clique, up to relabelling (orbits of `Perm (Fin 10)`), by
    Burnside's lemma over the cycle types from the certified counts above. -/
theorem tri10_orbits :
    Nat.card (MulAction.orbitRel.Quotient (Equiv.Perm (Fin 10))
      {G : SimpleGraph (Fin 10) // G.CliqueFree 3}) = 12172 :=
  CliqueFreeFam.card_orbits_eq 12172
    [([10], 14),
     ([9], 5),
     ([8, 2], 33),
     ([8], 21),
     ([7, 3], 5),
     ([7, 2], 18),
     ([7], 62),
     ([6, 4], 29),
     ([6, 3], 37),
     ([6, 2, 2], 411),
     ([6, 2], 175),
     ([6], 511),
     ([5, 5], 110),
     ([5, 4], 19),
     ([5, 3, 2], 15),
     ([5, 3], 55),
     ([5, 2, 2], 177),
     ([5, 2], 525),
     ([5], 6565),
     ([4, 4, 2], 757),
     ([4, 4], 541),
     ([4, 3, 3], 41),
     ([4, 3, 2], 130),
     ([4, 3], 470),
     ([4, 2, 2, 2], 8855),
     ([4, 2, 2], 4091),
     ([4, 2], 12643),
     ([4], 145079),
     ([3, 3, 3], 1049),
     ([3, 3, 2, 2], 427),
     ([3, 3, 2], 1371),
     ([3, 3], 17711),
     ([3, 2, 2, 2], 3970),
     ([3, 2, 2], 12214),
     ([3, 2], 139290),
     ([3], 4682270),
     ([2, 2, 2, 2, 2], 770649),
     ([2, 2, 2, 2], 298993),
     ([2, 2, 2], 811213),
     ([2, 2], 8440837),
     ([2], 251030385),
     ([], 19213627145)]
    (List.forall_mem_cons.2 ⟨tri10_fix_10,
      List.forall_mem_cons.2 ⟨tri10_fix_9,
      List.forall_mem_cons.2 ⟨tri10_fix_8_2,
      List.forall_mem_cons.2 ⟨tri10_fix_8,
      List.forall_mem_cons.2 ⟨tri10_fix_7_3,
      List.forall_mem_cons.2 ⟨tri10_fix_7_2,
      List.forall_mem_cons.2 ⟨tri10_fix_7,
      List.forall_mem_cons.2 ⟨tri10_fix_6_4,
      List.forall_mem_cons.2 ⟨tri10_fix_6_3,
      List.forall_mem_cons.2 ⟨tri10_fix_6_2_2,
      List.forall_mem_cons.2 ⟨tri10_fix_6_2,
      List.forall_mem_cons.2 ⟨tri10_fix_6,
      List.forall_mem_cons.2 ⟨tri10_fix_5_5,
      List.forall_mem_cons.2 ⟨tri10_fix_5_4,
      List.forall_mem_cons.2 ⟨tri10_fix_5_3_2,
      List.forall_mem_cons.2 ⟨tri10_fix_5_3,
      List.forall_mem_cons.2 ⟨tri10_fix_5_2_2,
      List.forall_mem_cons.2 ⟨tri10_fix_5_2,
      List.forall_mem_cons.2 ⟨tri10_fix_5,
      List.forall_mem_cons.2 ⟨tri10_fix_4_4_2,
      List.forall_mem_cons.2 ⟨tri10_fix_4_4,
      List.forall_mem_cons.2 ⟨tri10_fix_4_3_3,
      List.forall_mem_cons.2 ⟨tri10_fix_4_3_2,
      List.forall_mem_cons.2 ⟨tri10_fix_4_3,
      List.forall_mem_cons.2 ⟨tri10_fix_4_2_2_2,
      List.forall_mem_cons.2 ⟨tri10_fix_4_2_2,
      List.forall_mem_cons.2 ⟨tri10_fix_4_2,
      List.forall_mem_cons.2 ⟨tri10_fix_4,
      List.forall_mem_cons.2 ⟨tri10_fix_3_3_3,
      List.forall_mem_cons.2 ⟨tri10_fix_3_3_2_2,
      List.forall_mem_cons.2 ⟨tri10_fix_3_3_2,
      List.forall_mem_cons.2 ⟨tri10_fix_3_3,
      List.forall_mem_cons.2 ⟨tri10_fix_3_2_2_2,
      List.forall_mem_cons.2 ⟨tri10_fix_3_2_2,
      List.forall_mem_cons.2 ⟨tri10_fix_3_2,
      List.forall_mem_cons.2 ⟨tri10_fix_3,
      List.forall_mem_cons.2 ⟨tri10_fix_2_2_2_2_2,
      List.forall_mem_cons.2 ⟨tri10_fix_2_2_2_2,
      List.forall_mem_cons.2 ⟨tri10_fix_2_2_2,
      List.forall_mem_cons.2 ⟨tri10_fix_2_2,
      List.forall_mem_cons.2 ⟨tri10_fix_2,
      List.forall_mem_cons.2 ⟨CliqueFreeFam.fix_nil tri10,
      List.forall_mem_nil _⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩⟩)
    (by decide)

/-- The number of isomorphism classes of graphs on 10 vertices without a 3-clique. -/
theorem tri10_isoClasses :
    Nat.card (Quot fun G H : {G : SimpleGraph (Fin 10) // G.CliqueFree 3} => Nonempty (G.1 ≃g H.1)) = 12172 :=
  CliqueFreeFam.card_isoClasses_eq tri10_orbits

#print axioms tri10_orbits
#print axioms tri10_isoClasses
#print axioms tri10
