import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream domino_8x8 via (Domino.card_of_check (R := 8) (C := 8)) "/scratch/szeider/120984/val_dom08/fwd.pog" "/scratch/szeider/120984/val_dom08/fwd.lrat" (keep := "/scratch/szeider/120984/val_dom08/fwd.keep") (count := 12988816)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms domino_8x8
