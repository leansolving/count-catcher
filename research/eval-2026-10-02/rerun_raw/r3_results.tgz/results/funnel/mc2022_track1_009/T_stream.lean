import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_009_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_009.cnf" "/scratch/szeider/121499/mc2022_track1_009/fwd.pog" "/scratch/szeider/121499/mc2022_track1_009/fwd.lrat" (keep := "/scratch/szeider/121499/mc2022_track1_009/fwd.keep") (count := 274877906944)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_009_models
