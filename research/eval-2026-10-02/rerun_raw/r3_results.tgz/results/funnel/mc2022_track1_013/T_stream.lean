import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_013_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_013.cnf" "/scratch/szeider/121500/mc2022_track1_013/fwd.pog" "/scratch/szeider/121500/mc2022_track1_013/fwd.lrat" (keep := "/scratch/szeider/121500/mc2022_track1_013/fwd.keep") (count := 70368744177664)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_013_models
