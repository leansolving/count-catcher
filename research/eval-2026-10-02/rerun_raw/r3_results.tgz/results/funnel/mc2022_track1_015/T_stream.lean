import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_015_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_015.cnf" "/scratch/szeider/121509/mc2022_track1_015/fwd.pog" "/scratch/szeider/121509/mc2022_track1_015/fwd.lrat" (keep := "/scratch/szeider/121509/mc2022_track1_015/fwd.keep") (count := 28311552)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_015_models
