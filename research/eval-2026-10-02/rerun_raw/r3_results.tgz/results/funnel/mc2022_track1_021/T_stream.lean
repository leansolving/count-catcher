import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_021_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_021.cnf" "/scratch/szeider/120985/mc2022_track1_021/fwd.pog" "/scratch/szeider/120985/mc2022_track1_021/fwd.lrat" (keep := "/scratch/szeider/120985/mc2022_track1_021/fwd.keep") (count := 784637825987894704862177297051569632016580688841015296000)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_021_models
