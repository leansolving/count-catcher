import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_027_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_027.cnf" "/scratch/szeider/121454/mc2022_track1_027/fwd.pog" "/scratch/szeider/121454/mc2022_track1_027/fwd.lrat" (keep := "/scratch/szeider/121454/mc2022_track1_027/fwd.keep") (count := 871298969811201013358239745009707359451910274409801440852991323817933978804924437624122059275091611673710189720816195146750733542311468188158689793614684351044709476824683519888292818262283830197405778778721545237930321507936257864154550160360541845514870178977037448920175009071104)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_027_models
