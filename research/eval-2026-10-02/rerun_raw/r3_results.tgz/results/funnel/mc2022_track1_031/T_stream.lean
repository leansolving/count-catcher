import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_031_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_031.cnf" "/scratch/szeider/121461/mc2022_track1_031/fwd.pog" "/scratch/szeider/121461/mc2022_track1_031/fwd.lrat" (keep := "/scratch/szeider/121461/mc2022_track1_031/fwd.keep") (count := 1383011137639135775863865344)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_031_models
