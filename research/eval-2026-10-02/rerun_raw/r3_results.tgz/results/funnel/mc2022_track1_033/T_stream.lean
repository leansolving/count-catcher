import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_033_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_033.cnf" "/scratch/szeider/121504/mc2022_track1_033/fwd.pog" "/scratch/szeider/121504/mc2022_track1_033/fwd.lrat" (keep := "/scratch/szeider/121504/mc2022_track1_033/fwd.keep") (count := 4611686018427387904)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_033_models
