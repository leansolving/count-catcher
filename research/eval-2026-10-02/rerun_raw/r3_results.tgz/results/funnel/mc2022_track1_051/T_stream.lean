import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_051_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_051.cnf" "/scratch/szeider/121485/mc2022_track1_051/fwd.pog" "/scratch/szeider/121485/mc2022_track1_051/fwd.lrat" (keep := "/scratch/szeider/121485/mc2022_track1_051/fwd.keep") (count := 44499729951278627285692951953778103131041706213661979403475021211936535985030524365051002880000)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_051_models
