import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_083_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_083.cnf" "/scratch/szeider/121328/mc2022_track1_083/fwd.pog" "/scratch/szeider/121328/mc2022_track1_083/fwd.lrat" (keep := "/scratch/szeider/121328/mc2022_track1_083/fwd.keep") (count := 295311547867400859023294652399876891681488896)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_083_models
