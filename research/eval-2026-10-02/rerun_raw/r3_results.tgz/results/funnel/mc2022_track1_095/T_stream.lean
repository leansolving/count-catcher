import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_095_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_095.cnf" "/scratch/szeider/121457/mc2022_track1_095/fwd.pog" "/scratch/szeider/121457/mc2022_track1_095/fwd.lrat" (keep := "/scratch/szeider/121457/mc2022_track1_095/fwd.keep") (count := 5)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_095_models
