import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_109_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_109.cnf" "/scratch/szeider/121462/mc2022_track1_109/fwd.pog" "/scratch/szeider/121462/mc2022_track1_109/fwd.lrat" (keep := "/scratch/szeider/121462/mc2022_track1_109/fwd.keep") (count := 63609)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_109_models
