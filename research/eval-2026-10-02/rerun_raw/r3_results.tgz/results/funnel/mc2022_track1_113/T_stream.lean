import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_113_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_113.cnf" "/scratch/szeider/121388/mc2022_track1_113/fwd.pog" "/scratch/szeider/121388/mc2022_track1_113/fwd.lrat" (keep := "/scratch/szeider/121388/mc2022_track1_113/fwd.keep") (count := 655954180492066106158360)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_113_models
