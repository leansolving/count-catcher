import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_121_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_121.cnf" "/scratch/szeider/121297/mc2022_track1_121/fwd.pog" "/scratch/szeider/121297/mc2022_track1_121/fwd.lrat" (keep := "/scratch/szeider/121297/mc2022_track1_121/fwd.keep") (count := 2630067950774186753620494941440064332775169901411586929749140451534366077148540411056833268138794225613491484428089108856509716125091901931563907385325940424977611835564222299095831878942161358635646625867890688)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_121_models
