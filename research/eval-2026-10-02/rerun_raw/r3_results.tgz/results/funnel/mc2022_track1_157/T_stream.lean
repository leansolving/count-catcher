import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_157_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_157.cnf" "/scratch/szeider/121229/mc2022_track1_157/fwd.pog" "/scratch/szeider/121229/mc2022_track1_157/fwd.lrat" (keep := "/scratch/szeider/121229/mc2022_track1_157/fwd.keep") (count := 7)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_157_models
