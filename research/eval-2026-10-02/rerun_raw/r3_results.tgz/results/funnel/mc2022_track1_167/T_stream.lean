import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_167_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_167.cnf" "/scratch/szeider/121346/mc2022_track1_167/fwd.pog" "/scratch/szeider/121346/mc2022_track1_167/fwd.lrat" (keep := "/scratch/szeider/121346/mc2022_track1_167/fwd.keep") (count := 15000)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_167_models
