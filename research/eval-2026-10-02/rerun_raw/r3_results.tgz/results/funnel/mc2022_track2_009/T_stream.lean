import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_009_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_009.cnf" "/scratch/szeider/121495/mc2022_track2_009/fwd.pog" "/scratch/szeider/121495/mc2022_track2_009/fwd.lrat" (keep := "/scratch/szeider/121495/mc2022_track2_009/fwd.keep") (count := 38277218304)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_009_models
