import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_013_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_013.cnf" "/scratch/szeider/121508/mc2022_track2_013/fwd.pog" "/scratch/szeider/121508/mc2022_track2_013/fwd.lrat" (keep := "/scratch/szeider/121508/mc2022_track2_013/fwd.keep") (count := 455266533376)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_013_models
