import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_021_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_021.cnf" "/scratch/szeider/121503/mc2022_track2_021/fwd.pog" "/scratch/szeider/121503/mc2022_track2_021/fwd.lrat" (keep := "/scratch/szeider/121503/mc2022_track2_021/fwd.keep") (count := 17592186044416)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_021_models
