import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_027_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_027.cnf" "/scratch/szeider/121474/mc2022_track2_027/fwd.pog" "/scratch/szeider/121474/mc2022_track2_027/fwd.lrat" (keep := "/scratch/szeider/121474/mc2022_track2_027/fwd.keep") (count := 52312258426754448493793761890686615511881351669810229756460037765755369310788278479549458844064465374001333545175330733800)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_027_models
