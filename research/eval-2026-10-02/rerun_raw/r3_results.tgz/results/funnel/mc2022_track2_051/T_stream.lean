import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_051_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_051.cnf" "/scratch/szeider/121480/mc2022_track2_051/fwd.pog" "/scratch/szeider/121480/mc2022_track2_051/fwd.lrat" (keep := "/scratch/szeider/121480/mc2022_track2_051/fwd.keep") (count := 745889456677218468)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_051_models
