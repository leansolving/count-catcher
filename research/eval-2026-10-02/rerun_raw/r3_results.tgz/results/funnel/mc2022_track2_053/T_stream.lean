import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_053_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_053.cnf" "/scratch/szeider/121453/mc2022_track2_053/fwd.pog" "/scratch/szeider/121453/mc2022_track2_053/fwd.lrat" (keep := "/scratch/szeider/121453/mc2022_track2_053/fwd.keep") (count := 311028719207543778204161109787806295884444813202906058332642502596954930632856051101421355685188458879722441865388018278128598200)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_053_models
