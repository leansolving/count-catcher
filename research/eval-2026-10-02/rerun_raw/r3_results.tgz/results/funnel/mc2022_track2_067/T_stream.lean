import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_067_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_067.cnf" "/scratch/szeider/121505/mc2022_track2_067/fwd.pog" "/scratch/szeider/121505/mc2022_track2_067/fwd.lrat" (keep := "/scratch/szeider/121505/mc2022_track2_067/fwd.keep") (count := 78398662313265594368)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_067_models
