import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_089_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_089.cnf" "/scratch/szeider/121429/mc2022_track2_089/fwd.pog" "/scratch/szeider/121429/mc2022_track2_089/fwd.lrat" (keep := "/scratch/szeider/121429/mc2022_track2_089/fwd.keep") (count := 595304902896)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_089_models
