import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_111_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_111.cnf" "/scratch/szeider/121392/mc2022_track2_111/fwd.pog" "/scratch/szeider/121392/mc2022_track2_111/fwd.lrat" (keep := "/scratch/szeider/121392/mc2022_track2_111/fwd.keep") (count := 367277801472)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_111_models
