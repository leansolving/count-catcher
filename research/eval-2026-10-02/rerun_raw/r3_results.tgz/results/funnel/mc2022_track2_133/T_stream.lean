import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_133_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_133.cnf" "/scratch/szeider/121400/mc2022_track2_133/fwd.pog" "/scratch/szeider/121400/mc2022_track2_133/fwd.lrat" (keep := "/scratch/szeider/121400/mc2022_track2_133/fwd.keep") (count := 13816482745794642)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_133_models
