import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_139_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_139.cnf" "/scratch/szeider/121327/mc2022_track2_139/fwd.pog" "/scratch/szeider/121327/mc2022_track2_139/fwd.lrat" (keep := "/scratch/szeider/121327/mc2022_track2_139/fwd.keep") (count := 10956218896810645658568)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_139_models
