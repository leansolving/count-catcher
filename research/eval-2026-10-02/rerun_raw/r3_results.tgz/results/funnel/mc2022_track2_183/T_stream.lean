import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_183_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_183.cnf" "/scratch/szeider/121396/mc2022_track2_183/fwd.pog" "/scratch/szeider/121396/mc2022_track2_183/fwd.lrat" (keep := "/scratch/szeider/121396/mc2022_track2_183/fwd.keep") (count := 724152621485436659540387630662916505600)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_183_models
