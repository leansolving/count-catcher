import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream domino_12x12 via (Domino.card_of_check (R := 12) (C := 12)) "/scratch/szeider/121023/dom12/fwd.pog" "/scratch/szeider/121023/dom12/fwd.lrat" (keep := "/scratch/szeider/121023/dom12/fwd.keep") (count := 53060477521960000)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms domino_12x12
