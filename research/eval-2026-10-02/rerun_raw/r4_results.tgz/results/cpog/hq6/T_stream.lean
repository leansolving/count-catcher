import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream hypercube6_indepSets via (hypercube_card_of_check (n := 6)) "/scratch/szeider/121027/hq6/fwd.pog" "/scratch/szeider/121027/hq6/fwd.lrat" (keep := "/scratch/szeider/121027/hq6/fwd.keep") (count := 19768832143)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms hypercube6_indepSets
