import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream grid14_indepSets via (grid_card_of_check (n := 14)) "/scratch/szeider/121026/ind14/fwd.pog" "/scratch/szeider/121026/ind14/fwd.lrat" (keep := "/scratch/szeider/121026/ind14/fwd.keep") (count := 338752110195939290445247645371206783)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms grid14_indepSets
