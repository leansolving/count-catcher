import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_005_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_005.cnf" "/scratch/szeider/121071/mc2022_track1_005/fwd.pog" "/scratch/szeider/121071/mc2022_track1_005/fwd.lrat" (keep := "/scratch/szeider/121071/mc2022_track1_005/fwd.keep") (count := 2)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_005_models
