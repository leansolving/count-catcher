import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_007_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_007.cnf" "/scratch/szeider/121040/mc2022_track1_007/fwd.pog" "/scratch/szeider/121040/mc2022_track1_007/fwd.lrat" (keep := "/scratch/szeider/121040/mc2022_track1_007/fwd.keep") (count := 3321888768)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_007_models
