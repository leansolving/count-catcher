import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_011_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_011.cnf" "/scratch/szeider/121054/mc2022_track1_011/fwd.pog" "/scratch/szeider/121054/mc2022_track1_011/fwd.lrat" (keep := "/scratch/szeider/121054/mc2022_track1_011/fwd.keep") (count := 2399034408960)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_011_models
