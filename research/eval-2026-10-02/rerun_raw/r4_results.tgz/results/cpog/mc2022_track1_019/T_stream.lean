import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_019_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_019.cnf" "/scratch/szeider/121067/mc2022_track1_019/fwd.pog" "/scratch/szeider/121067/mc2022_track1_019/fwd.lrat" (keep := "/scratch/szeider/121067/mc2022_track1_019/fwd.keep") (count := 2348542582773833227889480596789337027375682548908319870707290971532209025114608443463698998384768703031934976)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_019_models
