import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_025_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_025.cnf" "/scratch/szeider/121076/mc2022_track1_025/fwd.pog" "/scratch/szeider/121076/mc2022_track1_025/fwd.lrat" (keep := "/scratch/szeider/121076/mc2022_track1_025/fwd.keep") (count := 995353648043325277633470371179901552767596542902694690949393806712545504789889138240157620657590241028863880769128775400)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_025_models
