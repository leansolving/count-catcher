import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_029_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_029.cnf" "/scratch/szeider/121126/mc2022_track1_029/fwd.pog" "/scratch/szeider/121126/mc2022_track1_029/fwd.lrat" (keep := "/scratch/szeider/121126/mc2022_track1_029/fwd.keep") (count := 15255690366224518443391643906855918971439224195778209534368207629482541229440174325510498605703791652267515850012141653009011400)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_029_models
