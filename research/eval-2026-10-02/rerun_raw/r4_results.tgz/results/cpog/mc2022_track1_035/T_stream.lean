import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_035_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_035.cnf" "/scratch/szeider/121047/mc2022_track1_035/fwd.pog" "/scratch/szeider/121047/mc2022_track1_035/fwd.lrat" (keep := "/scratch/szeider/121047/mc2022_track1_035/fwd.keep") (count := 1237940039285380274899124224)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_035_models
