import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_037_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_037.cnf" "/scratch/szeider/121061/mc2022_track1_037/fwd.pog" "/scratch/szeider/121061/mc2022_track1_037/fwd.lrat" (keep := "/scratch/szeider/121061/mc2022_track1_037/fwd.keep") (count := 261545906067383009253732022824600705687237029358521548800)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_037_models
