import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_039_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_039.cnf" "/scratch/szeider/121044/mc2022_track1_039/fwd.pog" "/scratch/szeider/121044/mc2022_track1_039/fwd.lrat" (keep := "/scratch/szeider/121044/mc2022_track1_039/fwd.keep") (count := 1208925819614629174706176)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_039_models
