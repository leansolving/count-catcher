import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_041_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_041.cnf" "/scratch/szeider/121172/mc2022_track1_041/fwd.pog" "/scratch/szeider/121172/mc2022_track1_041/fwd.lrat" (keep := "/scratch/szeider/121172/mc2022_track1_041/fwd.keep") (count := 55634325839448300217581691263457570909163964334080)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_041_models
