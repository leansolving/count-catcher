import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_043_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_043.cnf" "/scratch/szeider/121129/mc2022_track1_043/fwd.pog" "/scratch/szeider/121129/mc2022_track1_043/fwd.lrat" (keep := "/scratch/szeider/121129/mc2022_track1_043/fwd.keep") (count := 60)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_043_models
