import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_045_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_045.cnf" "/scratch/szeider/121070/mc2022_track1_045/fwd.pog" "/scratch/szeider/121070/mc2022_track1_045/fwd.lrat" (keep := "/scratch/szeider/121070/mc2022_track1_045/fwd.keep") (count := 617608961484928)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_045_models
