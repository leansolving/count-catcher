import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_047_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_047.cnf" "/scratch/szeider/121058/mc2022_track1_047/fwd.pog" "/scratch/szeider/121058/mc2022_track1_047/fwd.lrat" (keep := "/scratch/szeider/121058/mc2022_track1_047/fwd.keep") (count := 2268)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_047_models
