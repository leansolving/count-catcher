import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_055_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_055.cnf" "/scratch/szeider/121127/mc2022_track1_055/fwd.pog" "/scratch/szeider/121127/mc2022_track1_055/fwd.lrat" (keep := "/scratch/szeider/121127/mc2022_track1_055/fwd.keep") (count := 3525631833958153947506493845729219573911051778100525672540419907281676791976928486911093807356882419310320361605693440000000)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_055_models
