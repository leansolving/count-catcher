import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_057_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_057.cnf" "/scratch/szeider/121059/mc2022_track1_057/fwd.pog" "/scratch/szeider/121059/mc2022_track1_057/fwd.lrat" (keep := "/scratch/szeider/121059/mc2022_track1_057/fwd.keep") (count := 439334834526)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_057_models
