import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_059_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_059.cnf" "/scratch/szeider/121155/mc2022_track1_059/fwd.pog" "/scratch/szeider/121155/mc2022_track1_059/fwd.lrat" (keep := "/scratch/szeider/121155/mc2022_track1_059/fwd.keep") (count := 1019632806)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_059_models
