import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_065_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_065.cnf" "/scratch/szeider/121149/mc2022_track1_065/fwd.pog" "/scratch/szeider/121149/mc2022_track1_065/fwd.lrat" (keep := "/scratch/szeider/121149/mc2022_track1_065/fwd.keep") (count := 47262168)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_065_models
