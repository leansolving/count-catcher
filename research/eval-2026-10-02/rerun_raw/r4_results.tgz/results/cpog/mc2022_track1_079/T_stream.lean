import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_079_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_079.cnf" "/scratch/szeider/121057/mc2022_track1_079/fwd.pog" "/scratch/szeider/121057/mc2022_track1_079/fwd.lrat" (keep := "/scratch/szeider/121057/mc2022_track1_079/fwd.keep") (count := 4586997219164220772386231638857866352028015041291020614568415538003613758234015902621450039221458175000000)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_079_models
