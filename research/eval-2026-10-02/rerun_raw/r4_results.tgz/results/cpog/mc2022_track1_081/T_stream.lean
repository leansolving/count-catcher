import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_081_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_081.cnf" "/scratch/szeider/121085/mc2022_track1_081/fwd.pog" "/scratch/szeider/121085/mc2022_track1_081/fwd.lrat" (keep := "/scratch/szeider/121085/mc2022_track1_081/fwd.keep") (count := 325433210760)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_081_models
