import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_087_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_087.cnf" "/scratch/szeider/121062/mc2022_track1_087/fwd.pog" "/scratch/szeider/121062/mc2022_track1_087/fwd.lrat" (keep := "/scratch/szeider/121062/mc2022_track1_087/fwd.keep") (count := 248661618089101217592043121701899940370073055166828920881444525198718880000979763200000)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_087_models
