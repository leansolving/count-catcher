import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_091_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_091.cnf" "/scratch/szeider/121078/mc2022_track1_091/fwd.pog" "/scratch/szeider/121078/mc2022_track1_091/fwd.lrat" (keep := "/scratch/szeider/121078/mc2022_track1_091/fwd.keep") (count := 120)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_091_models
