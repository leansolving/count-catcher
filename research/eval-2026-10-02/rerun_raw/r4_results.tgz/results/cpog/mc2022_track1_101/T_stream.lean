import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_101_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_101.cnf" "/scratch/szeider/121165/mc2022_track1_101/fwd.pog" "/scratch/szeider/121165/mc2022_track1_101/fwd.lrat" (keep := "/scratch/szeider/121165/mc2022_track1_101/fwd.keep") (count := 1486848)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_101_models
