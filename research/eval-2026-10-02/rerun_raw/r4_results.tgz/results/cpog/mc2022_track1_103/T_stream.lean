import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_103_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_103.cnf" "/scratch/szeider/121158/mc2022_track1_103/fwd.pog" "/scratch/szeider/121158/mc2022_track1_103/fwd.lrat" (keep := "/scratch/szeider/121158/mc2022_track1_103/fwd.keep") (count := 362880)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_103_models
