import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_135_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_135.cnf" "/scratch/szeider/121156/mc2022_track1_135/fwd.pog" "/scratch/szeider/121156/mc2022_track1_135/fwd.lrat" (keep := "/scratch/szeider/121156/mc2022_track1_135/fwd.keep") (count := 6)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_135_models
