import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_141_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_141.cnf" "/scratch/szeider/121170/mc2022_track1_141/fwd.pog" "/scratch/szeider/121170/mc2022_track1_141/fwd.lrat" (keep := "/scratch/szeider/121170/mc2022_track1_141/fwd.keep") (count := 31014)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_141_models
