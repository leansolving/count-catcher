import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_153_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_153.cnf" "/scratch/szeider/121183/mc2022_track1_153/fwd.pog" "/scratch/szeider/121183/mc2022_track1_153/fwd.lrat" (keep := "/scratch/szeider/121183/mc2022_track1_153/fwd.keep") (count := 1536)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_153_models
