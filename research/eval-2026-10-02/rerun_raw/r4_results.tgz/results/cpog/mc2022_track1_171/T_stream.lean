import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_171_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_171.cnf" "/scratch/szeider/121182/mc2022_track1_171/fwd.pog" "/scratch/szeider/121182/mc2022_track1_171/fwd.lrat" (keep := "/scratch/szeider/121182/mc2022_track1_171/fwd.keep") (count := 23421510324076617565622131248)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_171_models
