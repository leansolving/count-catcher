import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_011_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_011.cnf" "/scratch/szeider/121178/mc2022_track2_011/fwd.pog" "/scratch/szeider/121178/mc2022_track2_011/fwd.lrat" (keep := "/scratch/szeider/121178/mc2022_track2_011/fwd.keep") (count := 1196885586994633113600)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_011_models
