import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_017_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_017.cnf" "/scratch/szeider/121045/mc2022_track2_017/fwd.pog" "/scratch/szeider/121045/mc2022_track2_017/fwd.lrat" (keep := "/scratch/szeider/121045/mc2022_track2_017/fwd.keep") (count := 19342813113834066795298816)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_017_models
