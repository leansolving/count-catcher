import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_029_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_029.cnf" "/scratch/szeider/121073/mc2022_track2_029/fwd.pog" "/scratch/szeider/121073/mc2022_track2_029/fwd.lrat" (keep := "/scratch/szeider/121073/mc2022_track2_029/fwd.keep") (count := 63884454600217751193206766137044710715406494851950527374745734055335032267567463806049821170151899288399696151556013800)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_029_models
