import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_031_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_031.cnf" "/scratch/szeider/121074/mc2022_track2_031/fwd.pog" "/scratch/szeider/121074/mc2022_track2_031/fwd.lrat" (keep := "/scratch/szeider/121074/mc2022_track2_031/fwd.keep") (count := 341444450139482308224179966046949096300663321302082456116934544166619653538477175319459880097322122924043805535912417102376877800)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_031_models
