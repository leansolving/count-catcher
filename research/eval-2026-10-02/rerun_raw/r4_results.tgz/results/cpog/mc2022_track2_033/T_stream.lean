import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_033_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_033.cnf" "/scratch/szeider/121122/mc2022_track2_033/fwd.pog" "/scratch/szeider/121122/mc2022_track2_033/fwd.lrat" (keep := "/scratch/szeider/121122/mc2022_track2_033/fwd.keep") (count := 994298489623589036)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_033_models
