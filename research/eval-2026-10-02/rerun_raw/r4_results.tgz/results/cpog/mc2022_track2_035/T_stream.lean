import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_035_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_035.cnf" "/scratch/szeider/121125/mc2022_track2_035/fwd.pog" "/scratch/szeider/121125/mc2022_track2_035/fwd.lrat" (keep := "/scratch/szeider/121125/mc2022_track2_035/fwd.keep") (count := 3008985149712482672109538849604652950378939869295256824090669174926333377493447253027197118060848380368802836284003938126741000)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_035_models
