import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_039_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_039.cnf" "/scratch/szeider/121081/mc2022_track2_039/fwd.pog" "/scratch/szeider/121081/mc2022_track2_039/fwd.lrat" (keep := "/scratch/szeider/121081/mc2022_track2_039/fwd.keep") (count := 1480701849511443905393013346560496787744154844493671369171989969767261352361321379280763528297094267046368320710923692624199400)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_039_models
