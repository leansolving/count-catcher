import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_043_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_043.cnf" "/scratch/szeider/121124/mc2022_track2_043/fwd.pog" "/scratch/szeider/121124/mc2022_track2_043/fwd.lrat" (keep := "/scratch/szeider/121124/mc2022_track2_043/fwd.keep") (count := 182569189736782637465420926684785985917484518340651257562184644476066677368186630764233379713449410277782110369872327969718277652200)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_043_models
