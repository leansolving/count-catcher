import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_045_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_045.cnf" "/scratch/szeider/121037/mc2022_track2_045/fwd.pog" "/scratch/szeider/121037/mc2022_track2_045/fwd.lrat" (keep := "/scratch/szeider/121037/mc2022_track2_045/fwd.keep") (count := 4503599627370496)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_045_models
