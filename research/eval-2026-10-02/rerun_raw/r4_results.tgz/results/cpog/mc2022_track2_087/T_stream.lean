import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_087_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_087.cnf" "/scratch/szeider/121171/mc2022_track2_087/fwd.pog" "/scratch/szeider/121171/mc2022_track2_087/fwd.lrat" (keep := "/scratch/szeider/121171/mc2022_track2_087/fwd.keep") (count := 343501410)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_087_models
