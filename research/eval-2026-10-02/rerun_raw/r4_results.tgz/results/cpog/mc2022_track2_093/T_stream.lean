import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_093_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_093.cnf" "/scratch/szeider/121115/mc2022_track2_093/fwd.pog" "/scratch/szeider/121115/mc2022_track2_093/fwd.lrat" (keep := "/scratch/szeider/121115/mc2022_track2_093/fwd.keep") (count := 18999521285301737931498072261884497312170104586240)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_093_models
