import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_095_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_095.cnf" "/scratch/szeider/121177/mc2022_track2_095/fwd.pog" "/scratch/szeider/121177/mc2022_track2_095/fwd.lrat" (keep := "/scratch/szeider/121177/mc2022_track2_095/fwd.keep") (count := 584637519343754869883653337453546734814776602425994666399673889754099168973607855517920860728684424864564367617045767640283857762707854851760455680000000000000)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_095_models
