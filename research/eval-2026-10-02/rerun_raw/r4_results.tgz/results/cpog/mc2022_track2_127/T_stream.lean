import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track2_127_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track2_127.cnf" "/scratch/szeider/121147/mc2022_track2_127/fwd.pog" "/scratch/szeider/121147/mc2022_track2_127/fwd.lrat" (keep := "/scratch/szeider/121147/mc2022_track2_127/fwd.keep") (count := 1032)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track2_127_models
