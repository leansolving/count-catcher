import McCertTool

open McCert SimpleGraph

#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"
count_models +stream mc2022_track1_069_models "/home1/szeider/mccert/scope/cnf/mc2022/mc2022_track1_069.cnf" "/scratch/szeider/121512/mc2022_track1_069/fwd.pog" "/scratch/szeider/121512/mc2022_track1_069/fwd.lrat" (keep := "/scratch/szeider/121512/mc2022_track1_069/fwd.keep") (count := 413881067600)
#eval show IO Unit from do IO.println s!"stamp {← IO.monoMsNow}"

#print axioms mc2022_track1_069_models
